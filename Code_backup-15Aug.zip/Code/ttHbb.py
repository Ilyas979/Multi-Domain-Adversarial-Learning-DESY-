import os
import random
import uproot
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm_notebook as tqdm
from keras.models import Model
from keras.models import Sequential
from keras.layers import Input, Reshape
from keras.layers.core import Dense, Activation, Dropout, Flatten
from keras.layers.normalization import BatchNormalization
from keras.layers.convolutional import UpSampling1D, Conv1D
from keras.layers.advanced_activations import LeakyReLU
from keras.optimizers import Adam, SGD
from keras.callbacks import TensorBoard
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score

N_events=100000
N_epochs=200
batch_size=500
Classifier_out_dim=1
Classifier_in_dim=44


def get_Classifier(Classifier_in_shape, dense_dim=50, droprate=.1, Classifier_out_dim=Classifier_out_dim, lr=1e-3):
    Classifier = Sequential()
    Classifier.add(Dense(dense_dim, input_dim=Classifier_in_dim, activation='relu'))
    Classifier.add(Dropout(droprate))
    Classifier.add(Dense(10, activation='relu'))
    Classifier.add(Dense(1, activation='sigmoid'))
    Classifier.compile(loss='binary_crossentropy', optimizer=Adam(lr=lr), metrics=['accuracy'])
    return Classifier

Classifier_in_shape = Input(shape=[Classifier_in_dim])
Classifier = get_Classifier(Classifier_in_shape)
Classifier.summary()

def get_discriminative(Discriminator_in_shape, lr=1e-3, droprate=.0, n_channels=50, conv_sz=1, leak=.2):
    
    x = Reshape((-1, 1))(Discriminator_in_shape)
    x = Conv1D(n_channels, conv_sz, activation='relu')(x)
    x = Dropout(droprate)(x)
    x = Flatten()(x)
    x = Dense(2)(x)
    D_out = Dense(1, activation='sigmoid')(x)
    D = Model(Discriminator_in_shape, D_out)
    #D = Sequential()
    #D.add(Dense(2, input_dim=Classifier_out_dim, activation='relu'))
    #D.add(Dense(1, activation='sigmoid'))
    D.compile(loss='binary_crossentropy', optimizer=Adam(lr=lr))
    return D

Discriminator_in_shape = Input(shape=[Classifier_out_dim])
D = get_discriminative(Discriminator_in_shape)
D.summary()

def set_trainability(model, trainable=False):
    model.trainable = trainable
    for layer in model.layers:
        layer.trainable = trainable
        
def make_gan(AdvNN_in, Classifier, D):
    set_trainability(D, False)
    x = Classifier(AdvNN_in)
    AdvNN_out = D(x)
    AdvNN_out = x
    AdvNN = Model(AdvNN_in, AdvNN_out)
    AdvNN.compile(loss='binary_crossentropy', optimizer=Classifier.optimizer)
    return AdvNN, AdvNN_out

AdvNN_in_shape = Input([Classifier_in_dim])
AdvNN, AdvNN_out = make_gan(AdvNN_in_shape, Classifier, D)
AdvNN.summary()

def load_Class_inputs(Classifier, n_samples=N_events):
    ttH = uproot.open("~/www/ttHbb_classifier/pre_selected_tev13_mg5_ttH_0001.root")["nominalAfterCuts"]
    ttH_df = ttH.pandas.df().head(N_events)

    ttbar = uproot.open("~/www/ttHbb_classifier/pre_selected_mg5_ttbar_jet_plus_b_merged.root")["nominalAfterCuts"]
    ttbar_df = ttbar.pandas.df().head(N_events)
    del ttH_df['weight_mc']
    del ttbar_df['weight_mc']
    del ttH_df['weight_xsec']
    del ttbar_df['weight_xsec']
    del ttH_df['weight_total']
    del ttbar_df['weight_total']
    del ttH_df['OverlapRemove']
    del ttbar_df['OverlapRemove']
    X = np.concatenate((ttH_df,ttbar_df)) # training data
    sc = StandardScaler()
    X = sc.fit_transform(X)
    y = np.concatenate((np.ones(ttH_df.shape[0]),np.zeros(ttbar_df.shape[0]))) # class lables
    X_train, X_other, y_train, y_other = train_test_split(X, y, test_size=0.50, random_state=42, stratify=y)
    X_test, X_alt, y_test, y_alt = train_test_split(X_other, y_other, test_size=0.50, random_state=43, stratify=y_other)
    X_alt[1]=X_alt[2]
    X_alt[2]=X_alt[3]
    X_alt[3]=X_alt[4]
    X_alt[4]=X_alt[5]
    X_alt[11]=X_alt[12]
    X_alt[12]=X_alt[13]
    X_alt[13]=X_alt[14]
    X_alt[14]=X_alt[15]
    X_alt[21]=X_alt[22]
    X_alt[22]=X_alt[23]
    X_alt[23]=X_alt[24]
    X_alt[24]=X_alt[25]
    X_alt[31]=X_alt[32]
    X_alt[32]=X_alt[33]
    X_alt[33]=X_alt[34]
    X_alt[34]=X_alt[35]
    X_alt[35]=X_alt[36]
    X_alt[36]=X_alt[37]
    X_alt[37]=X_alt[38]
    X_alt[38]=X_alt[39]
    X_alt[39]=X_alt[40]
    X_alt[42]=X_alt[43]
    X_alt[43]=X_alt[44]
    X_alt[44]=X_alt[0]
    #X_alt = np.random.uniform(0, 1, size=[N_events, Classifier_in_dim])
    #y = np.zeros((n_samples, 2))
    #y[:, 1] = 1
    return X_train, X_test, X_alt, y_train, y_test, y_alt
  
X_train, X_test, X_alt, y_train, y_test, y_alt = load_Class_inputs(Classifier, N_events)

  
def train(AdvNN, Classifier, D, X_train, X_test, X_alt, y_train, y_test, y_alt, epochs=N_epochs, n_samples=N_events, batch_size=batch_size, verbose=False, v_freq=10):
    d_loss = []
    class_loss = []
    test_scores = []
    alt_scores = []
    e_range = range(epochs)
    Classifier.fit(X_train,y_train,epochs=1,batch_size=batch_size)
    set_trainability(D, True)
    D.fit(Classifier.predict(X_test[y_test==0]), Classifier.predict(X_alt[y_alt==0]),epochs=1, batch_size=batch_size)
    test_scores.append(Classifier.predict(X_test[y_test==0]))
    alt_scores.append(Classifier.predict(X_alt[y_alt==0]))
    #if verbose:
        #e_range = tqdm(e_range)
    for epoch in e_range:
        #pred, alt = sample_data_and_gen(Classifier, n_samples)
        set_trainability(D, True)
        bkg_test=X_test[y_test==0] #move above loop
        bkg_alt=X_alt[y_alt==0] # move above loop
        Classifier_on_bkg_test=Classifier.predict(bkg_test)
        Classifier_on_bkg_alt=Classifier.predict(bkg_alt)
        d_loss.append(D.train_on_batch(Classifier_on_bkg_test, Classifier_on_bkg_alt))

        set_trainability(D, False)
        class_loss.append(AdvNN.train_on_batch(X_train, y_train))
        if verbose and (epoch + 1) % v_freq == 0:
            print("Epoch #{}: Classifier Loss: {}, Discriminator Loss: {}".format(epoch + 1, class_loss[-1], d_loss[-1]))
            test_scores.append(Classifier_on_bkg_test)
            alt_scores.append(Classifier_on_bkg_alt)
    return d_loss, class_loss, test_scores, alt_scores

d_loss, class_loss, test_scores, alt_scores = train(AdvNN, Classifier, D, X_train, X_test, X_alt, y_train, y_test, y_alt, verbose=True)  

scores = Classifier.evaluate(X_test, y_test, verbose=0)
print("%s: %.2f%%" % (Classifier.metrics_names[1], scores[1]*100))
Classifier.summary()
y_predicted = Classifier.predict(X_test)
print (classification_report(y_test, y_predicted.round(), target_names=["signal", "background"]) )
print ("Area under ROC curve: %.4f"%(roc_auc_score(y_test, y_predicted)) )

loss_plot = pd.DataFrame(
    {
        'Classifier Loss': class_loss,
        'Discriminator Loss': d_loss,
    }
).plot(title='Training loss', logy=False)
loss_plot.set_xlabel("Epochs")
loss_plot.set_ylabel("Loss")

#N_VIEWED_SAMPLES = 2
#data_and_gen, _ = sample_data_and_gen(Classifier, n_samples=N_VIEWED_SAMPLES)
#pd.DataFrame(np.transpose(data_and_gen[N_VIEWED_SAMPLES:])).rolling(5).mean()[5:].plot()
plt.show()
kwargs = dict(histtype='stepfilled', alpha=0.3, normed=True, bins=25)

plt.hist(test_scores[0], **kwargs)
plt.hist(alt_scores[0], **kwargs)
plt.show()
plt.hist(test_scores[10], **kwargs)
plt.hist(alt_scores[10], **kwargs)
plt.show()
plt.hist(test_scores[20], **kwargs)
plt.hist(alt_scores[20], **kwargs)
plt.show()
