# MLP with automatic validation set
import uproot, pandas
import matplotlib.pyplot as plt
from keras.models import Sequential
from keras.models import load_model
from keras.layers import Dense
from keras.layers import Dropout
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
import numpy as np


import seaborn as sns


# fix random seed for reproducibility
seed=8
np.random.seed(seed)

# load openData ttH dataset
limitNumberOfEvents = 0
ttH = uproot.open("../Data/pre_selected_tev13_mg5_ttH_0001.root")["nominalAfterCuts"]
ttH_df = ttH.pandas.df() #.head(limitNumberOfEvents)

ttbar = uproot.open("../Data/pre_selected_mg5_ttbar_jet_plus_b_merged.root")["nominalAfterCuts"]
ttbar_df = ttbar.pandas.df() #.head(limitNumberOfEvents)


#lazy way to remove the variables I do not want to train on
del ttH_df['weight_mc']
del ttbar_df['weight_mc']
del ttH_df['weight_xsec']
del ttbar_df['weight_xsec']
del ttH_df['weight_total']
del ttbar_df['weight_total']
del ttH_df['OverlapRemove']
del ttbar_df['OverlapRemove']


#print ("are the headers to same?")
#print ("ttH: ",ttH.keys())
#print ("ttbar: ",ttbar.keys())

#one object that hold both signal + background data, here X. And one object y that hold the class labels. The correspondence between X ans y if giving by the index (row number).
X = np.concatenate((ttH_df,ttbar_df)) # training data
sc = StandardScaler()
X = sc.fit_transform(X)
y = np.concatenate((np.ones(ttH_df.shape[0]),np.zeros(ttbar_df.shape[0]))) # class lables

#print (ttH_df.head(), ttbar_df.head())
sns.distplot(ttH_df['nJets'])

i=0
for col in ttH_df.columns[12:]:
  plt.hist(ttH_df[col], density = True, label='ttH')
  plt.hist(ttbar_df[col], density = True, label='ttbar')
  plt.title(col)
  plt.legend()
  plt.savefig('../Plots/Histograms/'+col)
  plt.show()
  i+=1
  print (col, i)

# do random split, take 2/3 for training, 1/3 for testing
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33)

'''
### define model
model = Sequential()
model.add(Dense(44, input_dim=44, activation='relu'))
#model.add(Dropout(rate=0.1, noise_shape=None, seed=None))
#model.add(Dense(50, activation='relu'))
#model.add(Dense(10, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

# Compile model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# Fit the model
model.fit(X_train, y_train, epochs=3, batch_size=100, verbose=0)

#store trained model
model.save('myttH_NN.h5')

#evaluate the trained model
scores = model.evaluate(X_test, y_test, verbose=0)
print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
model.summary()
y_predicted = model.predict(X_test)
print (classification_report(y_test, y_predicted.round(), target_names=["signal", "background"]) )
print ("Area under ROC curve: %.4f"%(roc_auc_score(y_test, y_predicted)) )
'''
