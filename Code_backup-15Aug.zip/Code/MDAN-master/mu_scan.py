import numpy as np
import time
import argparse
import pickle
import torch
import torch.optim as optim
import torch.nn.functional as F
from scipy.sparse import coo_matrix
from model import MDANet
from utils import get_logger
from utils import data_loader
from utils import multi_data_loader
import uproot, pandas
import matplotlib.pyplot as plt
import os

parser = argparse.ArgumentParser()
parser.add_argument("-u", "--max_mu", help="Hyperparameter of the coefficient for the domain adversarial loss", type=float, default=0.5)
parser.add_argument("-max_l", "--max_hidden_layers", help="Number of neurons in hidden layers.", nargs='+', type=int, default=[30, 10, 2])
parser.add_argument("-e", "--epoch", help="Number of training epochs", type=int, default=100)

args = parser.parse_args()
hid_lay = args.max_hidden_layers
epochs = args.epoch
mu = args.max_mu #mu 0.5
a_range = [150, 100, 50]
b_range = [200, 100, 50]
c_range = [150, 100, 50]
mu_range = [0, 0.25, 0.5, 1.0, 2.0, 4.0]
#[a, b, c] in range 
for mu in mu_range:
  for a in a_range:
    for b in b_range:
      for c in c_range:
        os.system("python main_ttH.py -e {} -u {} -l {} {} {}".format(epochs, mu, a, b, c))
        os.system("python plot_train_val_loss.py -u {} -l {} {} {}".format(mu, a, b, c))
        os.system("python plot_response.py -u {} -l {} {} {}".format(mu, a, b, c))


#mu_range = np.linspace(0.0, args.max_mu, 10, endpoint=True)

'''
for mu in mu_range:
  os.system("python main_ttH.py -e 200 -u {}".format(mu))
  os.system("python plot_train_val_loss.py -u {}".format(mu))
  os.system("python plot_response.py -u {}".format(mu))
'''
