#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import time
import argparse
import pickle
import torch
import torch.optim as optim
import torch.nn.functional as F
from scipy.sparse import coo_matrix
from no_adversary_model import MDANet
from utils import get_logger
from utils import data_loader
from utils import multi_data_loader
import uproot, pandas

parser = argparse.ArgumentParser()
parser.add_argument("-n", "--name", help="Name used to save the log file.", type=str, default="ttH")
parser.add_argument("-f", "--frac", help="Fraction of the supervised training data to be used.",
                    type=float, default=1.0)
parser.add_argument("-s", "--seed", help="Random seed.", type=int, default=42)
parser.add_argument("-v", "--verbose", help="Verbose mode: True -- show training progress. False -- "
                                            "not show training progress.", type=bool, default=True)
parser.add_argument("-m", "--model", help="Choose a model to train: [mdan]",
                    type=str, default="mdan")
# The experimental setting of using 48 dimensions of features is according to the papers in the literature.
parser.add_argument("-d", "--dimension", help="Number of features to be used in the experiment",
                    type=int, default=48)
parser.add_argument("-u", "--mu", help="Hyperparameter of the coefficient for the domain adversarial loss",
                    type=float, default=1e-2)
parser.add_argument("-e", "--epoch", help="Number of training epochs", type=int, default=15)
parser.add_argument("-b", "--batch_size", help="Batch size during training", type=int, default=1000)
parser.add_argument("-o", "--mode", help="Mode of combination rule for MDANet: [maxmin|dynamic]", type=str, default="dynamic")
# Compile and configure all the model parameters.
args = parser.parse_args()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

logger = get_logger(args.name)

# Set random number seed.
np.random.seed(args.seed)
torch.manual_seed(args.seed)

# Loading the randomly partition the ttH data set.
time_start = time.time()

ttH = uproot.open("../../Data/pre_selected_tev13_mg5_ttH_0001.root")["nominalAfterCuts"]
ttH_np = ttH.pandas.df().values
ttbar = uproot.open("../../Data/pre_selected_tev13_mg5_ttbar_0001.root")["nominalAfterCuts"]
ttbar_np = ttbar.pandas.df().values
ttbb = uproot.open("../../Data/pre_selected_tev13_ttbb_PP8delphes.root")["nominalAfterCuts"]
ttbb_np = ttbb.pandas.df().drop(columns = ['scalePDF']).values

time_end = time.time()

logger.info("Time used to process the ttH data set = {} seconds.".format(time_end - time_start))

logger.info("ttH_np shape = {}.".format(ttH_np.shape))
logger.info("ttbar_np shape = {}.".format(ttbar_np.shape))
logger.info("ttbb_np shape = {}.".format(ttbb_np.shape))
# Partition the data into three categories and for each category partition the data set into training and test set.
#maybe suffle first
N_events = 100000
num_data_sets = 3

if num_data_sets == 3:
	src_1 = coo_matrix(np.concatenate((ttH_np[:N_events], ttbar_np[:3*N_events]))).tocsc()
	y_src_1 = np.concatenate((np.ones(N_events),np.zeros(3*N_events)))

	src_2 = coo_matrix(np.concatenate((ttH_np[N_events:2*N_events], ttbb_np[:3*N_events]))).tocsc()
	y_src_2 = np.concatenate((np.ones(N_events),np.zeros(3*N_events)))

	target = coo_matrix(np.concatenate((ttH_np[2*N_events:3*N_events], ttbar_np[:3*N_events//2], ttbb_np[:3*N_events//2]))).tocsc()
	y_target = np.concatenate((np.ones(N_events), np.zeros(3*N_events)))

	data_insts, data_labels, num_insts = [], [], []
	data_name = ['src_1', 'src_2', 'target']

	data_insts.append(src_1)
	data_labels.append(y_src_1)
	num_insts.append(y_src_1.shape[0])

	data_insts.append(src_2)
	data_labels.append(y_src_2)
	num_insts.append(y_src_2.shape[0])

	data_insts.append(target)
	data_labels.append(y_target)
	num_insts.append(y_target.shape[0])
elif num_data_sets == 2:
	src = coo_matrix(np.concatenate((ttH_np[:N_events], ttbar_np[:3*N_events], ttH_np[N_events:2*N_events], ttbb_np[:3*N_events]))).tocsc()
	y_src = np.concatenate((np.ones(N_events), np.zeros(3*N_events), np.ones(N_events), np.zeros(3*N_events)))

	target = coo_matrix(np.concatenate((ttH_np[2*N_events:3*N_events], ttbar_np[:3*N_events//2], ttbb_np[:3*N_events//2]))).tocsc()
	y_target = np.concatenate((np.ones(N_events), np.zeros(3*N_events)))

	data_insts, data_labels, num_insts = [], [], []
	data_name = ['src', 'target']

	data_insts.append(src)
	data_labels.append(y_src)
	num_insts.append(y_src.shape[0])

	data_insts.append(target)
	data_labels.append(y_target)
	num_insts.append(y_target.shape[0])

for i in range(num_data_sets):
    r_order = np.arange(num_insts[i])
    np.random.shuffle(r_order)
    data_insts[i] = data_insts[i][r_order, :]
    data_labels[i] = data_labels[i].reshape((data_labels[i].shape[0], 1))
    data_labels[i] = data_labels[i][r_order, :]

logger.info("Data sets: {}".format(data_name))
logger.info("Number of total instances in the data sets: {}".format(num_insts))
# Partition the data set into training and test parts, following the convention in the ICML-2012 paper, use a fixed
# amount of instances as training and the rest as test.
num_trains = int(N_events * args.frac)
input_dim = ttH_np.shape[1]
# The confusion matrix stores the prediction accuracy between the source and the target tasks. The row index the source
# task and the column index the target task.
results = {}
logger.info("Training fraction = {}, number of actual training data instances = {}".format(args.frac, num_trains))
logger.info("-" * 100)

if args.model == "mdan":
    configs = {"input_dim": input_dim, "hidden_layers": [25, 15, 6], "num_classes": 2,
               "num_epochs": args.epoch, "batch_size": args.batch_size, "lr": 1.0, "mu": args.mu, "num_domains":
                   num_data_sets - 1, "mode": args.mode, "gamma": 10.0, "verbose": args.verbose}
    num_epochs = configs["num_epochs"]
    batch_size = configs["batch_size"]
    num_domains = configs["num_domains"]
    lr = configs["lr"]
    mu = configs["mu"]
    gamma = configs["gamma"]
    mode = configs["mode"]
    logger.info("Training with domain adaptation using PyTorch madnNet: ")
    logger.info("Hyperparameter setting = {}.".format(configs))
    error_dicts = {}
    for i in range(num_data_sets):
        # Build source instances.
        source_insts = []
        source_labels = []
        for j in range(num_data_sets):
            if j != i:
                source_insts.append(data_insts[j][:num_trains, :].todense().astype(np.float32))
                source_labels.append(data_labels[j][:num_trains, :].ravel().astype(np.int64))
        # Build target instances.
        target_idx = i
        target_insts = data_insts[i][num_trains:, :].todense().astype(np.float32)
        target_labels = data_labels[i][num_trains:, :].ravel().astype(np.int64)
        # Train DannNet.
        mdan = MDANet(configs).to(device)
        optimizer = optim.Adadelta(mdan.parameters(), lr=lr)
        mdan.train()
        # Training phase.
        time_start = time.time()
        for t in range(num_epochs):
            running_loss = 0.0
            train_loader = multi_data_loader(source_insts, source_labels, batch_size)
            for xs, ys in train_loader:
                slabels = torch.ones(batch_size, requires_grad=False).type(torch.LongTensor).to(device)
                tlabels = torch.zeros(batch_size, requires_grad=False).type(torch.LongTensor).to(device)
                for j in range(num_domains):
                    xs[j] = torch.tensor(xs[j], requires_grad=False).to(device)
                    ys[j] = torch.tensor(ys[j], requires_grad=False).to(device)
                ridx = np.random.choice(target_insts.shape[0], batch_size)
                tinputs = target_insts[ridx, :]
                tinputs = torch.tensor(tinputs, requires_grad=False).to(device)
                optimizer.zero_grad()
                logprobs, sdomains, tdomains = mdan(xs, tinputs)
                # Compute prediction accuracy on multiple training sources.
                losses = torch.stack([F.nll_loss(logprobs[j], ys[j]) for j in range(num_domains)])
                domain_losses = torch.stack([F.nll_loss(sdomains[j], slabels) +
                                           F.nll_loss(tdomains[j], tlabels) for j in range(num_domains)])
                # Different final loss function depending on different training modes.
                if mode == "maxmin":
                    loss = torch.max(losses) + mu * torch.min(domain_losses)
                elif mode == "dynamic":
                    loss = torch.log(torch.sum(torch.exp(gamma * (losses + mu * domain_losses)))) / gamma
                else:
                    raise ValueError("No support for the training mode on madnNet: {}.".format(mode))
                running_loss += loss.item()
                loss.backward()
                optimizer.step()
            logger.info("Iteration {}, loss = {}".format(t, running_loss))
        time_end = time.time()
        # Test on other domains.
        mdan.eval()
        target_insts = torch.tensor(target_insts, requires_grad=False).to(device)
        target_labels = torch.tensor(target_labels)
        preds_labels = torch.max(mdan.inference(target_insts), 1)[1].cpu().data.squeeze_()
        pred_acc = torch.sum(preds_labels == target_labels).item() / float(target_insts.size(0))
        error_dicts[data_name[i]] = preds_labels.numpy() != target_labels.numpy()
        logger.info("Prediction accuracy on {} = {}, time used = {} seconds.".
                    format(data_name[i], pred_acc, time_end - time_start))
        results[data_name[i]] = pred_acc
    logger.info("Prediction accuracy with multiple source domain adaptation using madnNet: ")
    logger.info(results)
    pickle.dump(error_dicts, open("{}-{}-{}-{}.pkl".format(args.name, args.frac, args.model, args.mode), "wb"))
    logger.info("*" * 100)
else:
    raise ValueError("No support for the following model: {}.".format(args.model))

