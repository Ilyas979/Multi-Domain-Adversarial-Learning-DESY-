import numpy as np
import time
import argparse
import pickle
import torch
import torch.optim as optim
import torch.nn.functional as F
from scipy.sparse import coo_matrix
from model import MDANet
from utils import get_logger
from utils import data_loader
from utils import multi_data_loader
import uproot, pandas
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve, auc

parser = argparse.ArgumentParser()
parser.add_argument("-u", "--mu", help="Hyperparameter of the coefficient for the domain adversarial loss", type=float, default=0.5)
parser.add_argument("-l", "--hidden_layers", help="Number of neurons in hidden layers.", nargs='+', type=int, default=[30, 10, 2])
args = parser.parse_args()

with open("./pred_scores/pred_scores-ttH-0.66-mdan-maxmin-mu_{}-l_{}.pkl".format(args.mu, args.hidden_layers), "rb") as f:
  y_score = pickle.load(f)
  y_test = pickle.load(f)

# Compute ROC curve and ROC area for each class


fpr, tpr, _ = roc_curve(y_test, y_score)
roc_auc = auc(fpr, tpr)

plt.figure()
lw = 1
plt.plot(fpr, tpr, color='darkorange',
         lw=lw, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic for ttH')
plt.legend(loc="lower right")
plt.savefig("../../Plots/ROC/roc_curve-mu_{}-l_{}.png".format(args.mu, args.hidden_layers), dpi = 300)
#plt.show()
