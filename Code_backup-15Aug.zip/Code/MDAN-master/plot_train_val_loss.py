import numpy as np
import time
import argparse
import pickle
import torch
import torch.optim as optim
import torch.nn.functional as F
from scipy.sparse import coo_matrix
from model import MDANet
from utils import get_logger
from utils import data_loader
from utils import multi_data_loader
import uproot, pandas
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser()
parser.add_argument("-u", "--mu", help="Hyperparameter of the coefficient for the domain adversarial loss", type=float, default=0.5)
parser.add_argument("-l", "--hidden_layers", help="Number of neurons in hidden layers.", nargs='+', type=int, default=[30, 10, 2])
args = parser.parse_args()

train_val_loss_dict = pickle.load(open("./train_val_loss_dict/train_val_loss_dict-ttH-0.66-mdan-maxmin-mu_{}-l_{}_last.pkl".format(args.mu, args.hidden_layers), "rb"))

# {'clf_losses': [], 'discr_losses' : [], 'total_loss_in_epoch': [], 'clf_losses_val': [], 'best_setting' : {'best_clf_loss_val': 1e10, 'accuracy': 0, 'epoch': 0} }
if args.mu == 0.0:
  for key in ['clf_losses', 'clf_losses_val']:
    plt.plot(train_val_loss_dict[key], label=key)
else:
  for key in ['clf_losses', 'discr_losses', 'clf_losses_val']:
    plt.plot(train_val_loss_dict[key], label=key)

plt.legend()
plt.savefig("../../Plots/Training_plots/train_val_loss_plot-mu_{}-l_{}_last.png".format(args.mu, args.hidden_layers), dpi = 300)
#plt.show()
"""
plt.plot(train_val_loss_dict['clf_losses'], label='clf_losses')
plt.legend()
plt.show()
"""
